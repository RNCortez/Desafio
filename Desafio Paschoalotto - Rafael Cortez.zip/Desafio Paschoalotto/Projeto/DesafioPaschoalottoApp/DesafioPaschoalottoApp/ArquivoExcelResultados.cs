﻿using ClosedXML.Excel;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;

namespace DesafioPaschoalottoApp
{
    class ArquivoExcelResultados
    {

        public static string GerarArquivo(ExcelConfiguracoes configuracoes, DateTime dataHoraInicioProcessamento, DateTime dataHoraFinalProcessamento,
            int quantidadeDadosProcessados, List<Resultado> resultados)
        {
            string caminhoArquivoResultado =
                configuracoes.DiretorioGeracaoArquivos +
                $"resultado {DateTime.Now.ToString("yyyy-MM-dd HH_mm_ss")}.xlsx";
            File.Copy(configuracoes.TemplateArquivoResultado, caminhoArquivoResultado);

            TimeSpan tempo = dataHoraFinalProcessamento.Subtract(dataHoraInicioProcessamento);
            decimal performance = Convert.ToDecimal(quantidadeDadosProcessados) / (Convert.ToDecimal((tempo.Hours * 60 * 60) + (tempo.Minutes * 60) + tempo.Seconds));

            using (var workbook = new XLWorkbook(caminhoArquivoResultado))
            {
                var worksheet = workbook.Worksheets.Worksheet(1);

                for (int i = 0; i < resultados.Count; i++)
                {
                    var res = resultados[i];
                    worksheet.Cell("A" + (5 + i)).Value = res.LogradouroNome;
                    worksheet.Cell("B" + (5 + i)).Value = res.BairroDistrito;
                    worksheet.Cell("C" + (5 + i)).Value = res.LocalidadeUF;
                    worksheet.Cell("D" + (5 + i)).Value = res.CEP;
                }
                worksheet.Cell("B2").Value = dataHoraInicioProcessamento;
                worksheet.Cell("D2").Value = dataHoraFinalProcessamento;
                worksheet.Cell("B3").Value = quantidadeDadosProcessados;
                worksheet.Cell("D3").Value = string.Concat(performance.ToString("N2", CultureInfo.InvariantCulture),"/Segundo");

                workbook.Save();
            }

            return caminhoArquivoResultado;
        }

    }
}
