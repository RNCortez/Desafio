﻿using ClosedXML.Excel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;

namespace DesafioPaschoalottoApp
{
    class ArquivoExcelCeps
    {
        private static int CountRows = 1;
        private static int Row = 1;
        public static List<string> CarregarListaCeps(ExcelConfiguracoes configuracoes)
        {
            List<string> listaRetorno = new List<string>();

            string caminhoArquivoCeps = configuracoes.ArquivoCeps;

            using (var workbook = new XLWorkbook(caminhoArquivoCeps))
            {
                var worksheet = workbook.Worksheets.Worksheet(1);

                var nonEmptyDataRows = workbook.Worksheet(1).RowsUsed();

                CountRows = workbook.Worksheet(1).RowsUsed().Count();

                foreach (var dataRow in nonEmptyDataRows)
                {
                    if (dataRow.RowNumber() > Row && dataRow.RowNumber() > 1)
                    {
                        listaRetorno.AddRange(ListaCepsFaixa(dataRow.Cell(2).Value.ToString(), dataRow.Cell(3).Value.ToString()));

                        Row++;

                        break;
                    }
                }
            }

            return listaRetorno;
        }

        private static List<string> ListaCepsFaixa(string cepInicial, string cepFinal)
        {
            List<string> listCepsRetorno = new List<string>();
            try
            {
                for (int i = Convert.ToInt32(cepInicial); i <= Convert.ToInt32(cepFinal); i++)
                {
                    listCepsRetorno.Add(i.ToString());
                }
            }
            catch (Exception) { }

            return listCepsRetorno;
        }

        public static bool FinalArquivo()
        {
            return Row > CountRows;
        }
    }
}
