﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace DesafioPaschoalottoApp
{
    class ExtracaoCeps
    {
        private SeleniumConfiguracoes _configuracoes;
        private IWebDriver _webDriver;
        private int QuantidadeDadosProcessados;

        public ExtracaoCeps(SeleniumConfiguracoes seleniumConfiguracoes)
        {
            QuantidadeDadosProcessados = 0;
            _configuracoes = seleniumConfiguracoes;
            ChromeOptions chromeOp = new ChromeOptions();

            //Argumento para execução em background do navegador
            chromeOp.AddArgument("--headless");

            _webDriver = new ChromeDriver(chromeOp);
        }

        public void CarregarPaginaCorreios()
        {
            _webDriver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(120);
            _webDriver.Navigate().GoToUrl(_configuracoes.UrlPaginaCorreios);
        }
        
        public List<Resultado> ResultadoExtracao(List<string> ListCeps)
        {
            List<Resultado> resultados = new List<Resultado>();
            

            foreach (var cep in ListCeps)
            {
                
                if (!ElementoVisivel(By.XPath("//p[contains(text(),'DADOS NAO ENCONTRADOS')]")) && !ElementoVisivel(By.XPath("//p[contains(text(),'DADOS ENCONTRADOS COM SUCESSO.')]")))
                {
                    try
                    {
                        PreencherInputsCep(cep, false);
                    }
                    catch (Exception)
                    {
                        PreencherInputsCep(cep, true);
                    }
                }
                else
                {
                    PreencherInputsCep(cep, true);
                }

                if (!ElementoVisivel(By.XPath("//p[contains(text(),'DADOS NAO ENCONTRADOS')]")) && ElementoVisivel(By.ClassName("tmptabela")))
                {
                    var rowsCep = _webDriver
                   .FindElement(By.ClassName("tmptabela"))
                   .FindElement(By.TagName("tbody"))
                   .FindElements(By.TagName("tr"));

                    int pos = 1;
                    foreach (var row in rowsCep)
                    {
                        if (pos > 1 && pos <= rowsCep.Count)
                        {
                            var dadosRow = row.FindElements(
                            By.TagName("td"));

                            Resultado res = new Resultado();
                            res.LogradouroNome = dadosRow[0].Text;
                            res.BairroDistrito = dadosRow[1].Text;
                            res.LocalidadeUF = dadosRow[2].Text;
                            res.CEP = dadosRow[3].Text;

                            resultados.Add(res);
                        }
                        pos++;
                    }
                }
                QuantidadeDadosProcessados++;
            }

            return resultados;
        }
        private void PreencherInputsCep(string cep, bool carregarPagina)
        {
            if (carregarPagina)
            {
                bool tenteCarregar = true;
                int tentativas = 1;
                while(tenteCarregar == true && tentativas <= 5)
                {
                    try
                    {
                        _webDriver.Navigate().GoToUrl(_configuracoes.UrlPaginaCorreios);
                        tenteCarregar = false;
                    }
                    catch (Exception){
                        tentativas++;
                    }
                }
                
            }
            FindElement(By.Name("relaxation"), 5).SendKeys(cep);
            _webDriver.FindElement(By.ClassName("btnform")).FindElement(By.TagName("input")).Click();
        }

        private IWebElement FindElement(By by, int timeoutInSeconds)
        {
            if (!ElementoVisivel(by) && timeoutInSeconds > 0)
            {
                var wait = new WebDriverWait(_webDriver, TimeSpan.FromSeconds(timeoutInSeconds));
                return wait.Until(drv => drv.FindElement(by));
            }
            return _webDriver.FindElement(by);
        }
        private bool ElementoVisivel(By by)
        {
            try
            {
                _webDriver.FindElement(by);
                return true;
            }
            catch (NoSuchElementException)
            {
                return false;
            }
        }

        public void Fechar()
        {
            _webDriver.Quit();
            _webDriver = null;
        }

        public int getQuantidadeDadosProcessamento()
        {
            return this.QuantidadeDadosProcessados;
        }
    }
}
