﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DesafioPaschoalottoApp
{
    class ExcelConfiguracoes
    {
        public string TemplateArquivoResultado { get; set; }
        public string DiretorioGeracaoArquivos { get; set; }
        public string ArquivoCeps { get; set; }
    }
}
