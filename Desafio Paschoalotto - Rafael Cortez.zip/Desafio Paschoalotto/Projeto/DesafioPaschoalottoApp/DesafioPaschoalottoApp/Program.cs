﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;

namespace DesafioPaschoalottoApp
{
    class Program
    {
        public static IConfigurationRoot Configuration { get; set; }

        static void Main(string[] args)
        {
            var builder = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile($"appsettings.json");

            Configuration = builder.Build();

            //Configurações do Excel
            var excelConfigurations = new ExcelConfiguracoes();
            new ConfigureFromConfigurationOptions<ExcelConfiguracoes>(
                Configuration.GetSection("ExcelConfiguracoes"))
                    .Configure(excelConfigurations);


            //Configurações do Selenium
            var seleniumConfiguracoes = new SeleniumConfiguracoes();
            new ConfigureFromConfigurationOptions<SeleniumConfiguracoes>(
                Configuration.GetSection("SeleniumConfiguracoes"))
                    .Configure(seleniumConfiguracoes);

           

            Console.WriteLine("Executando a extração...");
            var dataHoraInicio = DateTime.Now;
            List<Resultado> resultados = new List<Resultado>();
            int quantidadeDadosProcessados = 0;
            Task[] tasks = new Task[4];
            int taskCount = 0;
            
            while (!ArquivoExcelCeps.FinalArquivo() /*&& (DateTime.Now.Hour - dataHoraInicio.Hour) < 1*/)
            {
                try
                {
                    if(taskCount > 3)
                    {
                        try
                        {
                            Task.WaitAll(tasks);
                        }
                        catch (AggregateException ae)
                        {
                            Console.WriteLine("Uma ou mais excessões ocorreram: ");
                            foreach (var ex in ae.Flatten().InnerExceptions)
                            {
                                Console.WriteLine($"{ex.Message}");
                            }
                        }
                    }

                    if (taskCount < 4)
                    {
                        List<string> listCeps = ArquivoExcelCeps.CarregarListaCeps(excelConfigurations);

                        tasks[taskCount] = Task.Run(() =>
                        {
                            taskCount++;
                            //extração na Pagina do Correios
                            var extracaoCeps = new ExtracaoCeps(seleniumConfiguracoes);
                            extracaoCeps.CarregarPaginaCorreios();

                            List<Resultado> res = extracaoCeps.ResultadoExtracao(listCeps);
                            if (res.Count > 0)
                            {
                                resultados.AddRange(res);
                            }
                            
                            quantidadeDadosProcessados += extracaoCeps.getQuantidadeDadosProcessamento();
                            extracaoCeps.Fechar();
                            taskCount--;
                        });
                    }
                }
                catch (Exception)
                {
                    break;
                }
            }
            
            if(resultados.Count > 0)
            {
                var dataHoraFinal = DateTime.Now;

                string arquivoResultadoXlsx = ArquivoExcelResultados.GerarArquivo(
                    excelConfigurations, dataHoraInicio, dataHoraFinal, quantidadeDadosProcessados, resultados);
                Console.WriteLine($"O arquivo {arquivoResultadoXlsx} foi gerado com sucesso!");
            }
            else
            {
                Console.WriteLine("Nenhum CEP extraído!");
            }
           
        }
    
    }
}
