﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DesafioPaschoalottoApp
{
    class SeleniumConfiguracoes
    {
        public string UrlPaginaCorreios { get; set; }
        public int TimeOut { get; set; }
    }
}
