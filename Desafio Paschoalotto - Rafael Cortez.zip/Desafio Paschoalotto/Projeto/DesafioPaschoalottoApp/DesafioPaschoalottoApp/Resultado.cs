﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DesafioPaschoalottoApp
{
    class Resultado
    {
        public string LogradouroNome { get; set; }
        public string BairroDistrito { get; set; }
        public string LocalidadeUF { get; set; }
        public string CEP { get; set; }
    }
}
